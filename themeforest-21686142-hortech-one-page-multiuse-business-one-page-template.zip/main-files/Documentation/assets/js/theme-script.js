/* ------------------------------------------------
  Project:   Hortech - Responsive HTML5 Template
  Build:     Bootstrap 4.0.0
  Author:    ThemeHt
------------------------------------------------ */
/* ------------------------
    Table of Contents

  1. Predefined Variables
  2. Scroll to top
  3. Scrolling Animation
  4. Fixed Header
  5. HT Window load and functions
  

------------------------ */

"use strict";


/*------------------------------------
  HT Predefined Variables
--------------------------------------*/
var $window = $(window),
    $document = $(document),
    $body = $('body');


//Check if function exists
$.fn.exists = function () {
  return this.length > 0;
};


function pretty() {
  $('a[href^=http]').bind('click',function(){
    window.open($(this).attr('href'));
    return false;
  });
  
  window.prettyPrint && prettyPrint();
}


/*------------------------------------
  HT Scroll to top
--------------------------------------*/
function scrolltop() {
  var $goToTop = $('#scroll-top');
      $goToTop.hide();
      $window.scroll(function(){
        if ($window.scrollTop()>100) $goToTop.fadeIn();
        else $goToTop.fadeOut();
      });
    $goToTop.on("click", function () {
      $('body,html').animate({scrollTop:0},1000);
      return false;
  });
}


/*------------------------------------
  HT Scrolling Animation
--------------------------------------*/
function scrolling() {
    $('.nav-item a, .move').bind('click', function(event) {
        var $anchor = $(this);
    var hg = $('header').height();
    var scroll_h = $($anchor.attr('href')).offset().top + (hg-50);
        $('html, body').stop().animate({
            scrollTop: scroll_h
        }, 1200);
        event.preventDefault();
    });
};


/*------------------------------------
  HT Fixed Header
--------------------------------------*/
function fxheader() {
$(window).scroll(function(){
    if ($(window).scrollTop() >= 600) {
       $('#header-wrap').addClass('fixed-header');
    }
    else {
       $('#header-wrap').removeClass('fixed-header');
    }
 });
};


/*------------------------------------
  HT Window load and functions
--------------------------------------*/
$(document).ready(function() {
    pretty(),
    scrolltop(),
    scrolling(),
    fxheader();
});





  
